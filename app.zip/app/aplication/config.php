<?php 

class DataBaseConfig
{
	public $default = array(
		"drive" => "mysql",
		"host" => "localhost",
		"username" => "root",
		"password" => "",
		"database" => "money"
		);
	//Base de datos de prueba.
	public $test = array(
		"drive" => "mysql",
		"host" => "localhost",
		"username" => "root",
		"password" => "",
		"database" => "test"
		);
}