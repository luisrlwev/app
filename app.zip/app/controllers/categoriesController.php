<?php 

class Categories extends AppController
{
	public function index(){
		$categories = $this->db->find("categories","all");
		$this->set("categories", $categories);
	}
	public function add(){
		if ($_POST) {
			if ($this->db->save("categories", $_POST)) {
				$this->redirect(array("controller"=>"categories"));
			}else{
				$this->redirect(array("controller"=>"categories", "action"=>"add"));
			}
		}
	}
	public function edit($args){
		
		if ($_POST) {
			if (!empty($_POST["new_categories"])) {
				$filter = new Validations();
				$pass = new Password();

				$_POST["new-categories"] = $filter->sanitizeText($_POST["new_password"]);
				$_POST["password"] = $pass->getPassword($_POST["password"]);
			}

			if ($this->db->update("users", $_POST)) {
				$this->redirect(array("controller"=>"users"));
			}else{
				$this->redirect(array("controller"=>"users", "acction"=>"edit"));
			}
		}
		$user = $this->db->find("users", "first", array("conditions"=>"users.id=".$args[0]));
		$this->set("user", $user);
		
	}

	public function delete(){
     if ($_GET) {
       if (!empty($_GET['id'])) {
          $condition = "id=".$_GET['id'];
             $this->db->delete("categories", $condition);
        if ($this->db->numberRows>0) {
          echo "¡Registro eliminado!";
             } 
          else{
         echo "Registro no eliminado";
         }
       }
      }
	}
}
?>