<form action="<?php echo APP_URL; ?>categories/delete" method="POST">
  <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
</form>