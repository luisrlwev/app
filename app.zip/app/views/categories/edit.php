<form action="<?php echo APP_URL; ?>users/edit " method="POST">
 	<input type="hidden" name="id" value="<?php echo $user['id']; ?>">

 	<p>
 		<label for="username">Category: </label>
 		<input type="text" name="new_category">
 	</p>
 	<p>
 		<input type="submit" value="Update">
 	</p>
 </form>