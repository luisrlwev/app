<form action="<?php echo APP_URL; ?>categories/add" method="post">
	<p>
		<label for="name">Name:</label>
		<input type="text" name="name">
	</p>
	<p>
		<input type="submit" value="Save">
	</p>
</form>