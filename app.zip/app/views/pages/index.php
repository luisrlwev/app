<h1>¡Hola Bienvenido a Money Tracking!</h1>
<p>Aquí podrás revisar el listado de usuarios que hay, los tipos de categorias, las transacciones que hay y las cuentas.
Además de que puedes añadir como eliminar.</p>