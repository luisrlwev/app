<h2>Listado de usuarios</h2>
<div class="col-md-1"><a href="<?php echo APP_URL; ?>users/add"><spam class="glyphicon glyphicon-plus"></spam></a></div>

<table border="1">
	<tr>
		<th>ID</th>
		<th>Nombre de usuario</th>
		<th>Rol</th>
		<th>Acción</th>
		<th>Contraseña</th>
	</tr>
	<?php foreach ($users as $user) : ?>
		<tr>
			<td><?php echo $user['id']; ?></td>
			<td><?php echo $user['username']; ?></td>
			<td><?php echo $user['rol']; ?></td>
			<td><?php echo $user['password']; ?></td>
			<td>
				<a href="<?php echo APP_URL;?>users/edit/<?php echo $user['id']; ?>">Editar</a> |
				<a href="<?php echo APP_URL;?>users/delete/?id=<?php echo $user['id']; ?>"> Borrar</a>
			</td>
		</tr>
	<?php endforeach; ?>
</table>