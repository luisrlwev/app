<form action="<?php echo APP_URL; ?>users/add" method="POST">
	<p>
		<label for="username">Username</label>
		<input type="text" name="username" placeholder="Username">
	</p>
	<p>
		<label for="password">Password</label>
		<input type="password" name="password" placeholder="Password">
	</p>
	<p>
		<label for="rol">Rol</label>
		<input type="text" name="rol" placeholder="Rol">
	</p>
	<p>
		<input type="submit" value="Save">
	</p>
</form>