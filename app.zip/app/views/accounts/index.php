<div class="row">
	<div class="col-sm-11"><h3>Cuentas</h3></div>
	<div class="col-md-1"><a href="<?php echo APP_URL; ?>accounts/add"><spam class="glyphicon glyphicon-plus"></spam></a></div>
</div>
<table border="1">
	<tr>
		<td>Id</td>
		<td>Id de usuario</td>	
		<td>Nombre del Banco</td>
		<td>Acción</td>
	</tr>
<?php foreach ($accounts as $account ): ?>
    <tr>
		<td><?php echo $account['id']; ?></td>
		<td><?php echo $account['user_id']; ?></td>	
		<td><?php echo $account['name']; ?></td>
		<td>
		   <a href="<?php echo APP_URL; ?>accounts/edit/<?php echo $account["id"]; ?>">Edit</a>
		   <a href="<?php echo APP_URL; ?>accounts/delete/?id=<?php echo $account['id']; ?>">Delete</a>
			
		</td>
	</tr>
<?php endforeach; ?>

</table>