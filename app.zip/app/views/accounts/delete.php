<form action="<?php echo APP_URL; ?>accounts/delete" method="POST">
  <input type="hidden" name="id" value="<?php echo $account['id']; ?>">

</form>